var mysql = require("mysql2");

const connection = mysql.createConnection({
    host: 'Test',
    user: 'Alex',
    database: 'TestBase',
    password: '1qazxsw2'
  });

connection.connect(function(err){
  if (err) {
    return console.error("Ошибка: " + err.message);
  }
  else{
    console.log("Подключение к серверу MySQL успешно установлено");
  }
});

  connection.query(
    'SELECT * FROM Apartments order by NumberOfRooms desc',
    function(err, results, fields) {
      console.log(err);
      console.log(results);
      console.log(fields); 
    }
  );